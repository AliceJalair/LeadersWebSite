
このたびは、手書きフォント「からかぜ」をダウンロードくださりありがとうございます。
必ず以下の利用規格に目を通してからフォントをご使用いただきますよう、お願いいたします。
また、ダウンロードした時点で、以下の利用規約に同意したものとみなします。


【利用規約】
・商用・非商用を問わず利用可能です。二次創作物への利用も自由におこなってください。
・作者は著作権を放棄していません。自作発言はご遠慮ください。
・当フォントを利用して発生した、いかなる損害についても作者は責任を負いません。


【禁止事項】
・フォントデータの改変・無断転載・再配布・販売
・当フォントを利用した制作物、ロゴなどの商標登録
！webフォント化やアプリへの埋め込み、書籍などへの収録を希望される方は、必ず作者までご連絡ください。


【注意事項】
・予告なしにバージョンアップを行うことがあります。
・一部の端末、ソフトウェアでは使用できない場合がございます。


連絡は以下までお願いいたします。
エヌ岡　enuokaenu@gmail.com
https://enuoka.booth.pm/


---


This free font "karakaze" provided by enuoka.
It is royalty free for use in both personal and commercial projects.
You DO NOT have rights to redistribute, resell, license, sub-license or offer this resource to any third party.
If you want to use this resource as a part of your product(web, app, books, etc), please contact me.


contact:
enuoka　enuokaenu@gmail.com
https://enuoka.booth.pm/




Copyright © 2019 by enuoka. All rights reserved.
